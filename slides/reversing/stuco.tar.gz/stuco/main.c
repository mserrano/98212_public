#include <stdio.h>

extern int add_one(int x);
extern int add_two(int x, int y);
extern int sum_all(int x);
extern int sum_all_no_recurse(int x);
extern int fatorial(int x);
extern int mystery_function(char* string);

#ifndef NDEBUG
#define P(v) do { printf("%s %d\n", #v, v); } while (0)
#else
#define P(v) v
#endif

int main(int argc, char** argv) {
	P(add_one(2));
	P(add_two(3, 4));
	P(sum_all(4));
	P(sum_all_no_recurse(4));
	P(factorial(3));
	P(mystery_function("Hello, world\n"));
}
